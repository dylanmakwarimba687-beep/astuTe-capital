"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import Image from "next/image";

export default function MarketingPage() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Simple navbar */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-bold text-lg gradient-text">AstuteCapital</div>
          <nav className="flex items-center gap-3">
            <a href="/auth/login" className="text-sm hover:underline">Log in</a>
            <Button className="bg-emerald-600 hover:bg-emerald-700">Get Started</Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-r from-blue-900 to-indigo-700 text-white py-20 px-6 text-center">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-bold mb-6"
        >
          Get Funded. Trade Like a Pro.
        </motion.h1>
        <p className="text-lg md:text-xl mb-6 max-w-2xl mx-auto text-white/90">
          Pass a simple evaluation and access up to <span className="font-semibold">$200,000</span> in trading capital.
        </p>
        <div className="flex items-center justify-center gap-3">
          <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">Start Challenge</Button>
          <a href="#plans" className="text-white/90 underline text-lg">View Plans</a>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-10 bg-white border-t border-b">
        <div className="max-w-6xl mx-auto px-6 flex flex-wrap items-center justify-center gap-8">
          {["/trusted1.png","/trusted2.png","/trusted3.png","/trusted4.png"].map((src, idx) => (
            <div key={idx} className="relative h-12 w-32 grayscale hover:grayscale-0 transition">
              <Image src={src} alt="Trusted Partner" fill className="object-contain" />
            </div>
          ))}
        </div>
      </section>

      {/* Plans */}
      <section id="plans" className="py-20 px-6 max-w-7xl mx-auto grid gap-8 md:grid-cols-3">
        {[
          { title: "Starter", price: "$99", capital: "$10,000" },
          { title: "Pro", price: "$299", capital: "$50,000" },
          { title: "Elite", price: "$599", capital: "$200,000" },
        ].map((plan) => (
          <Card key={plan.title} className="shadow-lg hover:shadow-xl transition">
            <CardContent className="text-center py-10">
              <h3 className="text-xl font-bold mb-2">{plan.title}</h3>
              <p className="text-gray-500 mb-4">{plan.capital} Account</p>
              <p className="text-3xl font-bold mb-6">{plan.price}</p>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Select Plan</Button>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-100">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              { q: "How do I get funded?", a: "Sign up, complete the evaluation challenge, and start trading with our capital." },
              { q: "What markets can I trade?", a: "We support Forex, Indices, Commodities, and Crypto markets through MT4/MT5." },
              { q: "How are payouts handled?", a: "You can request payouts anytime. We process them within 24-48 hours via your preferred method." },
              { q: "Is there a time limit for the challenge?", a: "No, trade at your own pace. There is no time restriction on evaluations." },
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
                <h3 className="font-semibold text-lg mb-2">{item.q}</h3>
                <p className="text-gray-600">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-emerald-600 text-white text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-3">Ready to Start Trading?</h2>
        <p className="mb-6 opacity-90">Pass the challenge and trade our capital. Your success is our success.</p>
        <Button size="lg" variant="secondary">Sign Up Now</Button>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} AstuteCapital — All rights reserved.
      </footer>
    </div>
  );
}
